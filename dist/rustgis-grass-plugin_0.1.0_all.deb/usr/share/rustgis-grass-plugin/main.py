"""A RustGIS process plugin that runs GRASS GIS modules.

RustGIS starts this program once per call and speaks one JSON object per line
over standard input and output (see RustGIS docs/plugins.md). GRASS itself is
never linked: each run spawns the user's own installation.

Vector modules are geoprocessing tools: RustGIS hands them the layer's
features as GeoJSON and takes the result back the same way. Raster modules are
commands instead, because a tool gets no raster and makes no host requests;
a command asks RustGIS to export the layer and to add the result back (see
grass_bridge/raster.py).

Progress goes to RustGIS as {"progress": ...} lines, and GRASS modules report
their own percentages to MetaMonitor through its GRASS hook
(https://github.com/YannChemin/MetaMonitor).

SPDX-License-Identifier: Unlicense
"""

import json
import os
import pathlib
import sys

from grass_bridge import raster, session

HERE = pathlib.Path(__file__).parent


def emit(obj):
    """Write one protocol line."""
    print(json.dumps(obj), flush=True)


def progress(text):
    """Tell RustGIS what the run is doing now."""
    emit({"progress": text})


def log(text):
    """Add a line to the log, and to a tool's run messages."""
    emit({"log": text})


def call(op, params=None):
    """Make one host request and return its answer.

    :param op: a host operation (``host.layers``) or any command id RustGIS
        lets this plugin run within its permissions
    :return: the ``ok`` value
    :raises session.GrassError: when RustGIS refuses the request, so the
        reason reaches the user instead of a traceback
    """
    emit({"call": {"op": op, "params": params or {}}})
    line = sys.stdin.readline()
    if not line.strip():
        raise session.GrassError(f"RustGIS gave no answer to '{op}'")
    try:
        reply = json.loads(line)
    except ValueError as e:
        raise session.GrassError(f"unreadable answer to '{op}': {e}") from e
    if "error" in reply:
        raise session.GrassError(f"{op}: {reply['error']}")
    return reply.get("ok")


def load_modules():
    """Return the tool id to GRASS module map the generator wrote."""
    try:
        return json.loads((HERE / "modules.json").read_text())["modules"]
    except (OSError, ValueError, KeyError):
        return {}


def split_params(declared, given):
    """Split a tool's parameters into GRASS parameters and flags.

    :param declared: the tool's parameter list from the manifest
    :param given: what the user supplied
    :return: ``(params, flags)``
    """
    params, flags = {}, []
    for spec in declared:
        name = spec["name"]
        if name == "input":
            continue
        value = given.get(name, None)
        if value is None or value == "":
            continue
        if name.startswith("flag_"):
            if value is True:
                flags.append(name[len("flag_") :])
            continue
        if isinstance(value, bool):
            continue
        params[name] = value
    return params, flags


def run_tool(req, modules):
    """Run one GRASS module for a tool request and return its ``ok`` value."""
    tool = req["id"]
    module = modules.get(tool)
    if not module:
        raise ValueError(f"no GRASS module is mapped to '{tool}'")
    manifest = json.loads((HERE / "plugin.json").read_text())
    declared = next((t["params"] for t in manifest["tools"] if t["id"] == tool), [])

    given = req.get("params") or {}
    layer = given.get("input")
    if not layer:
        raise ValueError("no input layer was given")
    geojson = (req.get("layers") or {}).get(layer)
    if geojson is None:
        raise ValueError(f"the input layer '{layer}' did not arrive with the request")

    params, flags = split_params(declared, given)
    with session.Run(progress=progress) as run:
        result, messages = run.vector_tool(module, geojson, params, flags)

    count = len(result.get("features") or [])
    messages.append(f"{module}: {count} features written.")
    return {
        "layers": [{"name": f"{layer} {module}", "geojson": result}],
        "messages": messages[:200],
    }


def run_raster_command(req):
    """Run one GRASS raster module over a raster layer of the map.

    A tool could not do this: it gets no raster and makes no host requests.
    This command asks RustGIS to export the layer, works on the file, and asks
    it to add the result back. See ``grass_bridge/raster.py``.

    :param req: the command request
    :return: its ``ok`` value, the panel's new state included
    """
    command = req["id"]
    operation = raster.OPERATIONS[command]
    panel = req.get("panel") or {}
    values = panel.get("values") or {}

    layers = call("host.layers") or []
    nodes = raster.raster_nodes(layers)
    layer = raster.choose_raster(layers, values.get("raster"))
    name = str(layer.get("name"))

    exported = os.path.join(raster.output_dir(), f".export-{os.getpid()}.tif")
    target = raster.output_path(name, operation["suffix"])
    centre = None
    if operation["module"] == "r.viewshed":
        view = call("host.view") or {}
        centre = tuple((view.get("center") or [None, None])[:2])
        if centre[0] is None:
            raise session.GrassError("RustGIS did not say where the map is centred")

    progress(f"Exporting {name}...")
    call("share.exportRaster", {"layer": name, "path": exported})
    try:
        with raster.RasterRun(progress=progress) as run:
            messages = run.raster_tool(command, exported, target, values, centre)
    finally:
        try:
            os.remove(exported)
        except OSError:
            pass

    added = call(
        "layer.addData", {"path": target, "name": f"{name} {operation['suffix']}"}
    )
    messages.append(f"The result is kept at {target}.")
    for text in messages:
        log(text)
    call("host.notify", {"text": f"{operation['label']}: {messages[0]}"})
    return {
        "layer": added,
        "messages": messages,
        "panel": {
            "values": {"raster": str(layer.get("id"))},
            "items": {
                "raster": {"nodes": nodes},
                "source": {"text": name},
                "status": {"text": "\n".join(messages)},
            },
        },
    }


def panel_state(req):
    """Answer the panel's state when it is opened.

    It reads the map only, so it is no undo step.
    """
    layers = call("host.layers") or []
    nodes = raster.raster_nodes(layers)
    values = (req.get("panel") or {}).get("values") or {}
    chosen = values.get("raster")
    if chosen is not None and not any(n["id"] == str(chosen) for n in nodes):
        chosen = None
    if chosen is None:
        active = [
            layer for layer in layers if layer.get("raster") and layer.get("active")
        ]
        if active:
            chosen = str(active[0].get("id"))
        elif len(nodes) == 1:
            chosen = nodes[0]["id"]
    installed = session.version()
    status = (
        f"GRASS GIS {installed}."
        if installed
        else "GRASS GIS was not found. Install it, or set RUSTGIS_GRASS to its launcher."
    )
    if not nodes:
        status += " The map has no raster layer."
    return {
        "panel": {
            "values": {"raster": chosen} if chosen else {},
            "items": {
                "raster": {"nodes": nodes},
                "source": {
                    "text": next(
                        (n["label"] for n in nodes if n["id"] == chosen),
                        "No raster chosen",
                    )
                },
                "status": {"text": status},
            },
        }
    }


def run_command(req):
    """Answer one command request."""
    command = req.get("id")
    if command == "raster-state":
        return panel_state(req)
    if command in raster.OPERATIONS:
        return run_raster_command(req)
    raise ValueError(f"unknown command '{command}'")


def main():
    """Read one request, answer it, and exit."""
    line = sys.stdin.readline()
    if not line.strip():
        emit({"error": "no request"})
        return
    try:
        req = json.loads(line)
    except ValueError as e:
        emit({"error": f"unreadable request: {e}"})
        return
    try:
        if req.get("kind") == "tool":
            emit({"ok": run_tool(req, load_modules())})
        elif req.get("kind") == "command":
            emit({"ok": run_command(req)})
        else:
            emit({"error": f"unknown request '{req.get('id')}'"})
    except session.GrassError as e:
        emit({"error": str(e)})
    except (OSError, ValueError, KeyError) as e:
        emit({"error": f"{type(e).__name__}: {e}"})


if __name__ == "__main__":
    main()
